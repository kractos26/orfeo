<?
$masiva->mostrarError();
?>